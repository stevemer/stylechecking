#include <iostream>
using namespace std;

void foo(int m, int n) {
	int one, two, three;
	one = two = three = 0;
	for (int i = n + m; i > 0; i--) {
		if (i % 4) {
			one++;
		}
	}
	for (int i = 0; i < m; i++, n--) {
		for (int j = 0; j < n; j++) {
			two++;
		}
	}
	
	while (m > 0) {
		three++;
		m /= 2;
	}
	cout << "one: " << one << endl;
	cout << "two: " << two << endl;
	cout << "three: " << three << endl;
}

int main () {
        foo(10, 10);
        foo(100, 100);
        foo(1000, 1000);

        foo (10, 50);
        foo (100, 500);

        foo (50, 10);
        foo (500, 100);
}
			
