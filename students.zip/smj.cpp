#include "catalog.h"
#include "query.h"
#include "sort.h"
#include "index.h"
#include <cstring>

/* Consider using Operators::matchRec() defined in join.cpp
 * to compare records when joining the relations */
  
Status Operators::SMJ(const string& result,           // Output relation name
                      const int projCnt,              // Number of attributes in the projection
                      const AttrDesc attrDescArray[], // Projection list (as AttrDesc)
                      const AttrDesc& attrDesc1,      // The left attribute in the join predicate
                      const Operator op,              // Predicate operator
                      const AttrDesc& attrDesc2,      // The left attribute in the join predicate
                      const int reclen)               // The length of a tuple in the result relation
{
	cout << "Algorithm: SM Join" << endl;

	Status currentStatus = OK;
	HeapFile resultHeapFile = HeapFile(result, currentStatus);
    if (currentStatus != OK) return currentStatus;

	//calculate values for sorting
	int numUnpinned = bufMgr->numUnpinnedPages();
	int numSortingPages = numUnpinned * 0.8;

	int leftRecLen, rightRecLen;

	int attrCnt = 0;
	AttrDesc *attrDescs;
	currentStatus = attrCat->getRelInfo(attrDesc1.relName, attrCnt, attrDescs);
	if (currentStatus != OK) return currentStatus;
	int maxOffset = 0;
	int maxOffsetLen = 0;
	for (int i = 0; i < attrCnt; i++) {
		if (attrDescs[i].attrOffset > maxOffset) {
			maxOffset = attrDescs[i].attrOffset;
			maxOffsetLen = attrDescs[i].attrLen;
		}
	}
	leftRecLen = maxOffset + maxOffsetLen;

	attrCnt = 0;
	delete attrDescs;
	currentStatus = attrCat->getRelInfo(attrDesc2.relName, attrCnt, attrDescs);
	if (currentStatus != OK) return currentStatus;
	maxOffset = 0;
	maxOffsetLen = 0;
	for (int i = 0; i < attrCnt; i++) {
		if (attrDescs[i].attrOffset > maxOffset) {
			maxOffset = attrDescs[i].attrOffset;
			maxOffsetLen = attrDescs[i].attrLen;
		}
	}
	rightRecLen = maxOffset + maxOffsetLen;

	int leftTuplesInPage = PAGESIZE / leftRecLen;
	int rightTuplesInPage = PAGESIZE / rightRecLen;

	int leftNumTuples = leftTuplesInPage * numSortingPages;
	int rightNumTuples = rightTuplesInPage * numSortingPages;

	//sort both left and right datasets
	SortedFile leftSorted = SortedFile(attrDesc1.relName, attrDesc1.attrOffset, attrDesc1.attrLen, static_cast<Datatype>(attrDesc1.attrType), leftNumTuples, currentStatus);
	if (currentStatus != OK) return currentStatus;
	SortedFile rightSorted = SortedFile(attrDesc2.relName, attrDesc2.attrOffset, attrDesc2.attrLen, static_cast<Datatype>(attrDesc2.attrType), rightNumTuples, currentStatus);
	if (currentStatus != OK) return currentStatus;

	//initialize left pointer
	Record leftMergeRecord, rightMergeRecord;
	currentStatus = leftSorted.next(leftMergeRecord);
	if (currentStatus != OK) return currentStatus;
	currentStatus = leftSorted.setMark();
	if (currentStatus != OK) return currentStatus;

	//initialize right pointer
	currentStatus = rightSorted.next(rightMergeRecord);
	if (currentStatus != OK) return currentStatus;
	currentStatus = rightSorted.setMark();
	if (currentStatus != OK) return currentStatus;

	//while i haven't reached the end of either file

	Status leftStatus = OK;
	Status rightStatus = OK;
	while (currentStatus == OK) {
		int result = matchRec(leftMergeRecord, rightMergeRecord, attrDesc1, attrDesc2);
		if (result < 0) {
			currentStatus = leftSorted.next(leftMergeRecord);
			if (currentStatus != OK && currentStatus != FILEEOF) return currentStatus;
			if (currentStatus != FILEEOF) {
				currentStatus = leftSorted.setMark();
				if (currentStatus != OK) return currentStatus;
			}
		} 
		else if (result > 0) {
			currentStatus = rightSorted.next(rightMergeRecord);
			if (currentStatus != OK && currentStatus != FILEEOF) return currentStatus;
			if (currentStatus != FILEEOF) {
				currentStatus = rightSorted.setMark();
				if (currentStatus != OK) return currentStatus;
			}
		} else {

			//Insert the record
			Record resultRecord;
			resultRecord.data = operator new (reclen);
			resultRecord.length = 0;
			for (int i = 0; i < projCnt; i++) {
				if (attrDescArray[i].relName == attrDesc1.relName) {
					memcpy((char*)resultRecord.data + resultRecord.length,
						(char*)leftMergeRecord.data + attrDescArray[i].attrOffset,
						attrDescArray[i].attrLen);
				} else {
					memcpy((char*)resultRecord.data + resultRecord.length,
						(char*)rightMergeRecord.data + attrDescArray[i].attrOffset,
						attrDescArray[i].attrLen);
				}

				resultRecord.length += attrDescArray[i].attrLen;
			}
			
			RID outRID;
			resultHeapFile.insertRecord(resultRecord, outRID);

			//CHECK FOR DUPLICATES /////////////////////////////////////////

			Record oldLeft = leftMergeRecord;
			Record oldRight = rightMergeRecord;

			//Advance once
			currentStatus = leftSorted.next(leftMergeRecord);
			if (currentStatus != OK) return currentStatus;
			currentStatus = leftSorted.setMark();
			if (currentStatus != OK) return currentStatus;
			currentStatus = rightSorted.next(rightMergeRecord);
			if (currentStatus != OK) return currentStatus;
			currentStatus = rightSorted.setMark();
			if (currentStatus != OK) return currentStatus;

			//Continue to advance through duplicate values
			while (!matchRec(oldLeft, leftMergeRecord, attrDesc1, attrDesc1) && !matchRec(oldRight, rightMergeRecord, attrDesc2, attrDesc2)) {
				currentStatus = leftSorted.next(leftMergeRecord); 
				if (currentStatus != OK) return currentStatus;
				currentStatus = leftSorted.setMark();
				if (currentStatus != OK) return currentStatus;
				currentStatus = rightSorted.next(rightMergeRecord);
				if (currentStatus != OK) return currentStatus;
				currentStatus = rightSorted.setMark();
				if (currentStatus != OK) return currentStatus;
			}

			// Return to most recent set of matches after advancing past duplicates
			currentStatus = leftSorted.gotoMark();
			if (currentStatus != OK) return currentStatus;
			currentStatus = rightSorted.gotoMark();
			if (currentStatus != OK) return currentStatus;
			currentStatus = leftSorted.next(leftMergeRecord);
			if (currentStatus != OK) return currentStatus;
			currentStatus = rightSorted.next(rightMergeRecord);
			if (currentStatus != OK) return currentStatus;
		}
	}

	if (currentStatus != FILEEOF) return currentStatus;

	return OK;
}

