#include "catalog.h"
#include "query.h"
#include "index.h"
#include <cstring>
#include "utility.h"

/*
 * Inserts a record into the specified relation
 *
 * Returns:
 * 	OK on success
 * 	an error code otherwise
 */

Status Updates::Insert(const string& relation,      // Name of the relation
                       const int attrCnt,           // Number of attributes specified in INSERT statement
                       const attrInfo attrList[])   // Value of attributes specified in INSERT statement
{
    /* Your solution goes here */
	Status currentStatus = OK;
	int maxOffset = 0;
	int maxOffsetLength = 0;
	for (int i = 0; i < attrCnt; i++) {
		AttrDesc myAttrDescription;
		currentStatus = attrCat->getInfo(relation, attrList[i].attrName, 
				myAttrDescription);
		if (currentStatus != OK) return currentStatus;
		
		if (myAttrDescription.attrOffset > maxOffset) {
			maxOffset = myAttrDescription.attrOffset;
			maxOffsetLength = myAttrDescription.attrLen;
		}
	}

	Record myRecord;
	myRecord.data = operator new(maxOffset + maxOffsetLength);
	myRecord.length = maxOffset + maxOffsetLength;

	int indexedCount = 0;
	for (int i = 0; i < attrCnt; i++) {
		AttrDesc myAttrDescription;
		currentStatus = attrCat->getInfo(relation, attrList[i].attrName, 
				myAttrDescription);
		if (currentStatus != OK) return currentStatus;
		if (myAttrDescription.indexed) indexedCount++;

		memcpy(myRecord.data + myAttrDescription.attrOffset, attrList[i].attrValue, myAttrDescription.attrLen);		
	}

	HeapFile myHeapFile = HeapFile(relation, currentStatus);
	if (currentStatus != OK) return currentStatus;

	RID myRID;
	currentStatus = myHeapFile.insertRecord(myRecord, myRID);
	if (currentStatus != OK) return currentStatus;

	for (int i = 0; i < attrCnt; i++) {
		AttrDesc myAttrDescription;
		int unique = 0;
		attrCat->getInfo(relation, attrList[i].attrName, myAttrDescription);
		if (myAttrDescription.indexed) {
			Index myIndex = Index(
				myAttrDescription.relName,
				myAttrDescription.attrOffset,
				myAttrDescription.attrLen,
				static_cast<Datatype>(myAttrDescription.attrType),
				unique,
				currentStatus);
			if (currentStatus != OK) return currentStatus;
			else {
				myIndex.insertEntry(attrList[i].attrValue, myRID);
			}
		}
	}

	Utilities::Print(relation);
	
	return OK;	
}
