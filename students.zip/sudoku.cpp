#include "SudokuBoard.h"

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void printCommands()
{
   cout << "Commands:" << endl;
   cout << "  (P)lace a value: P <row> <col> <value>" << endl;
   cout << "  (D)elete a value: D <row> <col>" << endl;
   //cout << "  (C)heck solution" << endl;
   //cout << "  (W)rite current puzzle to file: <fileName>" << endl;
   //cout << "  (S)olve current puzzle" << endl;
   cout << "  (Q)uit" << endl;
}

bool getCoords(int & row, int & col) {
   char rowConv;
   int colConv;
   cin >> rowConv;
   cin >> colConv;
   if (rowConv >= 'a' && rowConv <= 'i')
       row = rowConv - 'a';
   else if (rowConv >= 'A' && rowConv <= 'I')
       row = rowConv - 'A';
   else {
       cout << "Invalid row";
       clearInput(cin);
       return false;
   }
   if (colConv >= 1 && colConv <= 9)
       col = colConv - 1;
   else {
       cout << "Invalid column";
       clearInput(cin);
       return false;
   }
   return true;
}

bool openFile(ifstream & ins) {
   if (ins.is_open())
       ins.close();
   cout << "Enter board filename: ";
   string filename;
   cin >> filename;
   ins.open(filename.c_str());
   if (ins.fail()) {
       cout << "Error opening file";
       ins.clear();
       return false;
   }
   else
       return true;
}

void clearInput(istream & ins) {
   string junk;
   ins.clear();
   getline(ins, junk);
}
