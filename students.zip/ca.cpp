#include <unordered_map>
#include <iostream>
#include <string>

int main () {
	std::unordered_map<std::string, std::string> m;
	m["key1"] = "value1";
	m["key2"] = "value2";
	for (auto i : m) {
		std::cout << i.first << " : " << i.second << std::endl;
	}
}
