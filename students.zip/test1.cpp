/**
 * PROGRAM: asciiart.cpp
 * AUTHOR: <#Jingyi Luo#>
 * UNIQNAME: <#luoji#>
 *
 * EECS 183: Project 3, Fall 2014
 *
 * <#A tester file for the program asciiart.cpp#>
 */

//#include "asciiart.h"
#include "asciiart.cpp"
#include <iostream>
#include <string>
#include <math.h>

int main(){
    printRectangle(2,3);
    printRectangle(4,5);
    printRectangle(10,1);

    printRectangle(2,3,3);
    printRectangle(5,6,0);
    printRectangle(10,1,1);

    printStringInBox("abcdefghijkl");
    printStringInBox(" ");
    printStringInBox("EECS 183");

    printRight(2);
    printRight(5);
    printRight(10);

    printRightWithSpaces(2);
    printRightWithSpaces(5);
    printRightWithSpaces(10);

    printIsosceles(2);
    printIsosceles(5);
    printIsosceles(10);

    printIsoscelesPointingDown(2);
    printIsoscelesPointingDown(5);
    printIsoscelesPointingDown(10);

    printDiamond(2);
    printDiamond(5);
    printDiamond(10);

    printArrow(2);
    printArrow(5);
    printArrow(10);

    cout << isPrime(1) << endl;
    cout << isPrime(2) << endl;
    cout << isPrime(5) << endl;
    cout << isPrime(10) << endl;

    printPrimes(1,10);
    printPrimes(10,1);
    printPrimes(2,12);
    printPrimes(5,20);

    printMersennePrimes(1,50);
    printMersennePrimes(50,1);
    printMersennePrimes(5,20);

    cout << sumProperDivisors(1) << endl;
    cout << sumProperDivisors(2) << endl;
    cout << sumProperDivisors(10) << endl;

    cout << isPerfect(1) << endl;
    cout << isPerfect(6) << endl;
    cout << isPerfect(20) << endl;

    cout << isAbundant(1) << endl;
    cout << isAbundant(6) << endl;
    cout << isAbundant(20) << endl;

    cout << isAmicable(1,10) << endl;
    cout << isAmicable(6,12) << endl;
    cout << isAmicable(8,20) << endl;

    return 0;
}
