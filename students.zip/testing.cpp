#include <iostream>
using namespace std;

int main () {
    char arr[] = {'1', '2', '3'};
    for (int i = 0; i < 3; i++) {
        cout << arr[i];
    }

    cout << endl << endl;

    cout << &arr;
    cout << endl;
}
