/*
 Kaitlyn Holmstrom (holms)
 Courtney Nash (courtnas)
 Project 4: Ciphers
 */

#include "ciphers.h"


void printArray(const char arr[], int size){
    if ((size > 0) && (size <= SIZE)) {
        for (int i = 0; i < size; i++) {
            cout << arr[i];
        }
        cout << endl;
    }
}


 void copyArray(const string source, char destination[], int& size){
     if(source.length() <= size){
        for (int i = 0; i < source.length(); i++) {
            destination[i] = source[i];
        }
         size = source.length();
     }
}

void erase(char arr[], int& size, int position, int count){
    if ((size > 0) && (size <= SIZE)){
        for (int i = 0; i < size; i++){
            if ((position + count) < size) {
                arr[position] = arr[position + count];
                position++;
            }
        }
        if (count > (size - position)) {
            size = position;
        } else {
            size = size - count;
        }
    }
}


void removeNonAlphas(char arr[], int& size, bool space){
    if ((size > 0) && (size <= SIZE)){
        if(space){
            for (int i = 0; i < size; i++){
                if (((arr[i] < 'A') || (arr[i] > 'Z')) &&
                    ((arr[i] < 'a') || (arr[i] > 'z'))){
                    erase(arr, size, i, 1);
                    i--;
                }
            }
        }
        else{
            for (int i = 0; i < size; i++){
                if (((arr[i] < 'A') || (arr[i] > 'Z')) &&
                    ((arr[i] < 'a') || (arr[i] > 'z')) && (arr[i] != ' ')){
                    erase(arr, size, i, 1);
                    i--;
                }
            }
        }
    }
}

char putCharacterIntoRange(int val){
    while (val < 65){
        val = val + ALPHABET_SIZE;
    }
    while (val > 90){
        val = val - ALPHABET_SIZE;
    }
    return val;
}


void toUpper(char arr[], int size){
    if ((size > 0) && (size <= SIZE)){
        for (int i = 0; i < size; i++){
            if ((arr[i] >= 'a') && (arr[i] <= 'z')){
                arr[i] = arr[i] - 32;
            }
        }
    }
}


void caesarCipher(char message[], int& size, int key){
    if ((size > 0) && (size <= SIZE)){
        removeNonAlphas(message, size, true);
        toUpper(message, size);
        for (int i = 0; i < size; i++){
            int val = (int) message[i] + key;
            message[i] = (char)val;
            putCharacterIntoRange(message[i]);
        }
    }
}

void copyArray(const string source, int destination[], int& size){
    for (int i = 0; i < source.length(); ++i) {
        int j = source[i];
        destination[i] = j;
    }
    size = source.length();
}

void printArrayAsCharacters(const int arr[], int size){
    if ((size > 0) && (size <= SIZE)){
        for (int i = 0; i < size; ++i) {
        cout << char (arr[i]);
        }
    }
    cout << endl;
}

void printArray(const int arr[], int size){
    if ((size > 0) && (size <= SIZE)){
        bool first = false;
        for (int i = 0; i < size ; ++i) {
            if (!first) {
                cout << arr[i];
                first = true;
            } else {
            cout << " " << arr[i];
            }
        }
    }
    cout << endl;
}

void caesarCipher(int arr[], int size, int key){
    if ((size > 0) && (size <= SIZE)){
        for (int i = 0; i < size; i++){
            int val = arr[i] + key;
            arr[i] = val;
            putCharacterIntoRange(arr[i]);
        }
    }
}

void upperCaseAndStrip(string str, char arr[], int& size, bool spaces){
    copyArray(str, arr, size);
    toUpper(arr, size);
    removeNonAlphas(arr, size, spaces);
}

void copyArray(char arr[], string& message, int size){}

void vigenereCipher(string& message, string key, char code){}

void adjustAndCleanKey(string origKey, char key[], int& size, bool spaces){}
/**
 Requires: The size of array arr is size && size > 0 && size <= SIZE.
 Modifies: arr and size.
 Effects:  Removes all duplicates within arr.
 Example:  char arr[] = {'A','B','C','B','D','E','C'};
 int size = 7;
 removeDuplicates(arr, size);
 printArray(arr, size); // will print: ABCDE
 cout << "Size is: " << size << endl; // prints: Size is: 5
 Calls:    find
 erase
 */
void removeDuplicates(char arr[], int& size){}
/*
    if ((size > 0) && (size <= SIZE)){
        for (int i = 0; i < size; ++ i) {
            if (find(arr, size, arr[i], i + 1)) {
                erase(arr, size, find(arr, size, arr[i], i + 1), 1);
                size -= 1;
                --i;
            }

        }
    
    }
    cout << "Size is: " << size << endl;
}*/


int find(const char arr[], int size, char target, int position){
    int i = position;
    int x = 0;
    if ((size > 0) && (size <= SIZE)){
        for (i; i < size; ++i) {
            if (arr[i] != target) {
                x = size;
            } else {
                x = i + 1;
                i += 26;
            }
        }
        
    }
    return x;
}

void monoAlphabetCipher(string& origMessage, string origKey, char code){}
