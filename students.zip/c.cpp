#include <iostream>
#define PRINT cout
#define AND <<
#define WAVE endl
#define DA <<
#define MAH int
#define FUNCSHUN main
#define ARGZ void
using namespace std;

MAH FUNCSHUN (ARGZ) {
    PRINT DA "HELLO";
    PRINT DA "EDWARD!" AND WAVE;
}
