#include "catalog.h"
#include "query.h"
#include "index.h"
#include <cstring>
#include "utility.h"
Status Operators::IndexSelect(const string& result,       // Name of the output relation
                              const int projCnt,          // Number of attributes in the projection
                              const AttrDesc projNames[], // Projection list (as AttrDesc)
                              const AttrDesc* attrDesc,   // Attribute in the selection predicate
                              const Operator op,          // Predicate operator
                              const void* attrValue,      // Pointer to the literal value in the predicate
                              const int reclen)           // Length of a tuple in the output relation
{
  cout << "Algorithm: Index Select" << endl;

  /* Your solution goes here */


	Status currentStatus = OK;
        HeapFileScan myHeapScan = HeapFileScan(projNames[0].relName, currentStatus);
	if (currentStatus != OK) return currentStatus;

	char *filter = (char*)attrValue;
	currentStatus = myHeapScan.startScan(attrDesc->attrOffset, attrDesc->attrLen, 
		static_cast<Datatype>(attrDesc->attrType), filter, op); 

        
	if (currentStatus != OK) return currentStatus; 
         
        HeapFile resultHeapFile = HeapFile(result, currentStatus);
        if (currentStatus != OK) return currentStatus;

        RID scanRID;

        Record resultRecord;
	
	//SPURIOUS USE OF SCANRID
        while ((currentStatus = myHeapScan.scanNext(scanRID, resultRecord)) == OK) {
		
		cout << "projCnt: " << projCnt << endl;
		Record finalRecord;
		finalRecord.data = new char[reclen];
		finalRecord.length = 0;
		
		//RID randRID;
		myHeapScan.getRandomRecord(scanRID, resultRecord);
		for (int i = 0; i < projCnt; i++) {
			memcpy((char*)finalRecord.data + finalRecord.length,
			       (char*)resultRecord.data + projNames[i].attrOffset,
			       projNames[i].attrLen);
			finalRecord.length += projNames[i].attrLen;
		}

		//RID outRID;
                resultHeapFile.insertRecord(finalRecord, scanRID);
		// is this neceessary?  move to top?
                if (currentStatus != OK) {
                        return currentStatus;
                }

		Utilities::Print(result);
        }

	//should probably check output status here

	return OK;


}
