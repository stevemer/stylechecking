#include <iostream>
using namespace std;

const int SIZE = 200;

void erase(char arr[], int& size, int position, int count) {
    if (size > 0 && size <= SIZE) {
        for (int j = position; j < size; ++j){
            if (j + count < size){
                arr[j] = arr[j + count];
            }
        }
    }
    if (position + count < size){
        size -= count;
    }
    else {
        size = position;
    }
}

void populate (char a[], int size) {
    for (int i = 0; i < size; i++) {
        a[i] = 'a' + i;
    }
}

void print(char a[], int size) {
    for (int i = 0; i < size; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
}

int main () {
    char a[10];
    populate(a, 10);
    cout << "Before: " << endl;
    print(a, 10);
    int a1 = 10;
    erase(a, a1, 5, 2);
    cout << "After: " << endl;
    print (a, a1);
}
