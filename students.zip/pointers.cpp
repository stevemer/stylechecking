/* A practice exercise using pointers in C++. */

#include <iostream>
using namespace std;

int main () {
    int a = -1;
    int b = 0;
    int *x = nullptr;
    int *y = nullptr;

    x = &a;
    cout << "*x=" << *x << endl;

    *x = 42;
    cout << "a=" << a << endl;

    y = x;
    cout << "*y=" << *y << " a=" << a << endl;

    *y = 13;
    cout << "*y=" << *y << endl;

    // leave this commented out till the end
    /*
    x = 0;
    cout << *x;
    */
}


