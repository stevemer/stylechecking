#include "catalog.h"
#include "query.h"
#include "index.h"

/*
 * Selects records from the specified relation.
 *
 * Returns:
 * 	OK on success
 * 	an error code otherwise
 */
Status Operators::Select(const string & result,      // name of the output relation
	                 const int projCnt,          // number of attributes in the projection
		         const attrInfo projNames[], // the list of projection attributes
		         const attrInfo *attr,       // attribute used inthe selection predicate 
		         const Operator op,         // predicate operation
		         const void *attrValue)     // literal value in the predicate
{
	// our status throughout all operations, passed to functions as return status
	Status currentStatus = OK;


	// Convert our attrInfo objects into the necessary attrDesc objects required by the Select operations

	int recLen = 0;

	AttrDesc *attrDescArray = new AttrDesc[projCnt];

	for (int i = 0; i < projCnt; ++i) {
		currentStatus = attrCat->getInfo(projNames[i].relName, projNames[i].attrName, attrDescArray[i]);
		if (currentStatus != OK) return currentStatus;
	}

	for (int i = 0; i < projCnt; i++) {
		recLen += attrDescArray[i].attrLen;	
	}

	// don't forget to calculate reclen
	
	AttrDesc predAttrDesc;

	// check if it's an index select, according to spec's definition of decision
	if (attr) {
		if ((currentStatus = attrCat->getInfo(attr->relName, attr->attrName,
				predAttrDesc)) == OK) {
			if (predAttrDesc.indexed && op == EQ) {
				currentStatus = IndexSelect(result, projCnt, attrDescArray, &predAttrDesc, op, attrValue, recLen);
				delete[] attrDescArray;
				return currentStatus;
			} 
		} else return currentStatus; 
	}

	// if it's not, it'll fall through to here, and run scan select
	currentStatus = ScanSelect(result, projCnt, attrDescArray, &predAttrDesc, op,
			attrValue, recLen);
	delete[] attrDescArray;
	return currentStatus;
}

