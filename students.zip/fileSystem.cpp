#include "rwlock.h"
#include <iostream>
#include <thread>
#include <time.h>

using namespace std;

rwlock l;
mutex coutm;
int threads;

void read(int counter) {
    time_t start = time(0);
    l.read_lock();
    l.read_unlock();
    coutm.lock();
    cout << counter << " read, start " << start << " end " << time(0) << "\n";
    --threads;
    coutm.unlock();
}

void write(int counter) {
    time_t start = time(0);
    l.write_lock();
    l.write_unlock();
    coutm.lock();
    cout << counter << " write, start " << start << " end " << time(0) << "\n";
    --threads;
    coutm.unlock();
}

int main() {
    coutm.lock();
    coutm.unlock();
    for (int i = 0; i < 30; ++i) {
        for (int j = 0; j < 10; ++j) {
            coutm.lock();
            ++threads;
            coutm.unlock();
            new thread(read, i*12+j);
        }
        coutm.lock();
        ++threads;
        coutm.unlock();
        new thread(write, i*12+11);
    }
    while (threads) {

    }
    return 0;
}
