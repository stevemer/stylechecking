#include <iostream>

int main () {
    std::cout << "Hello \" Peter \"\\/";//"Hello \"Egon";
}
