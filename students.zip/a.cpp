#include <iostream>
using namespace std;

int main () {
    char * x = NULL;
    cout << x << endl;
}
