//#include "fs_access.h"
#include "fs_server.h"
#include <iostream>
#include <cstring>
#include "fs_access.h"
#include <mutex>
#include <thread>

using namespace std;

int main() {
    fs_inode* root = new fs_inode;
    disk_readblock(0,(void*)root);
    root->blocks[0] = 1;

    fs_direntry fsd_direntries[DIRENTRIES_PER_BLOCK];
    cout << "Yay1" << endl;

    cout << "Yay2" << endl;

    fsd_direntries[0].name[0] = 's';
    fsd_direntries[0].name[1] = 't';
    fsd_direntries[0].name[2] = 'e';
    fsd_direntries[0].name[3] = 'v';
    fsd_direntries[0].name[4] = 'e';
    fsd_direntries[0].name[5] = 'm';
    fsd_direntries[0].name[6] = 'e';
    fsd_direntries[0].name[7] = 'r';
    fsd_direntries[0].name[8] = '\0';
    fsd_direntries[0].inode_block = 2;
    fs_inode* stevemer = new fs_inode;
    stevemer->type = 'f';
    stevemer->owner[0] = 'a';
    stevemer->owner[1] = '\0';
    stevemer->size = FS_BLOCKSIZE;
    stevemer->blocks[0]=7;
    char a[FS_BLOCKSIZE];
    a[0] = 'W';
    a[1] = 'h';
    a[2] = 'o';
    a[3] = 'o';
    a[4] = 's';
    a[5] = 'h';
    disk_writeblock(2,(const void*)stevemer);
    disk_writeblock(7,(const void*)a);

    fsd_direntries[1].name[0] = 'd';
    fsd_direntries[1].name[1] = 'd';
    fsd_direntries[1].name[2] = 'r';
    fsd_direntries[1].name[3] = 'o';
    fsd_direntries[1].name[4] = 'c';
    fsd_direntries[1].name[5] = 'c';
    fsd_direntries[1].name[6] = 'o';
    fsd_direntries[1].name[7] = '\0';
    fsd_direntries[1].inode_block = 3;
    fs_inode* ddrocco = new fs_inode;
    ddrocco->type = 'f';
    ddrocco->owner[0] = 'a';
    ddrocco->owner[1] = '\0';
    ddrocco->size = FS_BLOCKSIZE;
    ddrocco->blocks[0]=8;
    char b[FS_BLOCKSIZE];
    b[0] = 'K';
    b[1] = 'a';
    b[2] = 'b';
    b[3] = 'l';
    b[4] = 'a';
    b[5] = 'm';
    disk_writeblock(3,(const void*)ddrocco);
    disk_writeblock(8,(const void*)b);

    fsd_direntries[3].name[0] = 'p';
    fsd_direntries[3].name[1] = 'c';
    fsd_direntries[3].name[2] = 'h';
    fsd_direntries[3].name[3] = 'e';
    fsd_direntries[3].name[4] = 'n';
    fsd_direntries[3].name[5] = '\0';
    fsd_direntries[3].inode_block = 4;
    fs_inode* pchen = new fs_inode;
    pchen->type = 'f';
    pchen->owner[0] = 'a';
    pchen->owner[0] = '\0';
    pchen->size = FS_BLOCKSIZE * 4;
    pchen->blocks[0]=9;
    pchen->blocks[1]=10;
    pchen->blocks[2]=11;
    pchen->blocks[3]=12;
    disk_writeblock(4,(const void*)pchen);
    char c[FS_BLOCKSIZE];
    c[0] = 'E';
    c[1] = 'E';
    c[2] = 'C';
    c[3] = 'S';
    c[4] = '!';
    c[5] = '!';
    char d[FS_BLOCKSIZE];
    d[0] = 'M';
    d[1] = 'A';
    d[2] = 'T';
    d[3] = 'H';
    d[4] = 'S';
    d[5] = '!';
    char e[FS_BLOCKSIZE];
    e[0] = 'W';
    e[1] = 'T';
    e[2] = 'F';
    e[3] = 'B';
    e[4] = 'B';
    e[5] = 'Q';
    char f[FS_BLOCKSIZE];
    f[0] = 'O';
    f[1] = 'M';
    f[2] = 'G';
    f[3] = 'L';
    f[4] = 'O';
    f[5] = 'L';

    fsd_direntries[6].name[0] = 'i';
    fsd_direntries[6].name[1] = 'n';
    fsd_direntries[6].name[2] = 't';
    fsd_direntries[6].name[3] = 'b';
    fsd_direntries[6].name[4] = '\0';
    fsd_direntries[6].inode_block = 5;
    fs_inode* intb = new fs_inode;
    intb->type = 'f';
    intb->owner[0] = 'a';
    intb->owner[1] = '\0';
    intb->size = FS_BLOCKSIZE;
    intb->blocks[0]=13;
    char g[FS_BLOCKSIZE];
    g[0] = 'I';
    g[1] = 'S';
    g[2] = ' ';
    g[3] = 'T';
    g[4] = 'H';
    g[5] = 'A';
    g[6] = 'T';
    g[7] = ' ';
    g[8] = 'A';
    g[9] = ' ';
    g[10] = 'J';
    g[11] = 'O';
    g[12] = 'K';
    g[13] = 'E';
    disk_writeblock(13,(const void*)g);

    fsd_direntries[8].name[0] = 'b';
    fsd_direntries[8].name[1] = 'j';
    fsd_direntries[8].name[2] = 'l';
    fsd_direntries[8].name[3] = 'o';
    fsd_direntries[8].name[4] = 'v';
    fsd_direntries[8].name[5] = 'e';
    fsd_direntries[8].name[6] = '\0';
    fsd_direntries[8].inode_block = 6;
    fs_inode* bjlove = new fs_inode;
    bjlove->type = 'f';
    bjlove->owner[0] = 'a';
    bjlove->owner[1] = '\0';
    bjlove->size = FS_BLOCKSIZE;
    bjlove->blocks[0]=14;
    char h[FS_BLOCKSIZE];
    h[0] = 'I';
    h[1] = '<';
    h[2] = '3';
    h[3] = 'B';
    h[4] = 'J';
    h[5] = 'S';
    disk_writeblock(14,(const void*)h);
    disk_writeblock(1,(const void*)fsd_direntries);
    disk_writeblock(9,(const void*)c);
    disk_writeblock(10,(const void*)d);
    disk_writeblock(11,(const void*)e);
    disk_writeblock(12,(const void*)f);


    char z[FS_BLOCKSIZE];
    cout << "Starting readblock." << endl;
    const char* k3 = "/pchen";
    server_rw_block(k3,2*FS_BLOCKSIZE,z,READBLOCK);
    cout << "THIS IS MY OUTPUT!"  << z << endl;

    disk_writeblock(0,(void*)root);

    fs_inode* root_read = new fs_inode;
    disk_readblock(0,(void*)root_read);
    cout << "BLOCK POINTED TO BY ROOT: " << root_read->blocks[0] << endl;

    while (true) {}

    char k[FS_BLOCKSIZE];
    const char* k2 = "Steve Merritt says hello.  Say hello back please.\0";
    strcpy(k,k2);
    const char* k4 = "/stevemer";
    server_rw_block(k4,2*FS_BLOCKSIZE,k2,READBLOCK);
    char m[FS_BLOCKSIZE];
    server_rw_block(k4,2*FS_BLOCKSIZE,m,READBLOCK);
    cout << m << endl;

    return 1;
}
