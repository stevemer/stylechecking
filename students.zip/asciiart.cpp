/**
 * PROGRAM: asciiart.cpp
 * AUTHOR: <#Jingyi Luo#>
 * UNIQNAME: <#luoji#>
 *
 * EECS 183: Project 3, Fall 2014
 *
 * <#The implementation of functions creating Ascii Art.#>
 */

//#include "asciiart.h"
//#include "test1.cpp"
#include <iostream>
#include <string>
#include <math.h>

using namespace std;

void printRectangle(int rows, int cols){
    for(int i = 1; i <= rows; i++){
        for(int j = 1; j <= cols; j++){
            cout << "*";
        }
        cout << endl;
    }
}

void printRectangle(int rows, int cols, int offset){
    for(int i = 1; i <= rows; i++){
        for(int k = 1; k <= offset; k++){
            cout << " ";
        }
        for(int j = 1; j <= cols; j++){
            cout << "*";
        }
        cout << endl;
    }
    cout << endl;
}

void printStringInBox(string str){
    int length = str.length();
    for(int i = 1; i <= length + 4; i++){
        cout << "*";
    }
    cout << endl;
    cout << "*" << " " << str << " " << "*" << endl;
    for(int i = 1; i <= length + 4; i++){
        cout << "*";
    }
    cout << endl;
}

void printRight(int n){
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= i; j++){
            cout << "*";
        }
        cout << endl;
    }
}

void printRightWithSpaces(int n){
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= i; j++){
            cout << "*";
            if(i != 1 && j != i){
                cout << " ";
            }
        }
        cout << endl;
    }
}

void printIsosceles(int n){
    for(int i = 1; i <= n; i++){
        for(int k = 1; k <= n-i; k++){
        cout << " ";
        }
    for(int j = 1; j <= i; j++){
            cout << "*";
            if(i != 1 && j != i){
                cout << " ";
            }
    }
    cout << endl ;
    }
    cout << endl;
}

void printIsoscelesPointingDown(int n){
    for(int i = n; i >= 1; i--){
        for(int k = 1; k <= n-i; k++){
        cout << " ";
        }
    for(int j = 1; j <= i; j++){
            cout << "*";
            if(i != 1 && j != i){
                cout << " ";
            }
    }
    cout << endl;
    }
    cout << endl;
}

void printDiamond(int n){
    for(int i = 1; i <= n; i++){
        for(int k = 1; k <= n-i; k++){
        cout << " ";
        }
    for(int j = 1; j <= i; j++){
            cout << "*";
            if(i != 1 && j != i){
                cout << " ";
            }
    }
    cout << endl;
    }
    for(int i = n-1; i >= 1; i--){
        for(int k = 1; k <= n-i; k++){
        cout << " ";
        }
    for(int j = 1; j <= i; j++){
            cout << "*";
            if(i != 1 && j != i){
                cout << " ";
            }
    }
    cout << endl;
    }
    cout << endl;
}

void printArrow(int n){
    int longestRow = 4 * n +3;
    int space;
    if(longestRow % 2 == 0){
        space = longestRow / 2;
    }
    else{
        space = longestRow / 2 + 1;
    }
    int counter = 1;
    int arrowHead = longestRow - space;
    for(int k = 1; k <= arrowHead / 2; k++){
        for(int i = 1; i <= space; i++){
        cout << " ";
        }
        for(int j = 1; j <= counter; j++){
            cout << "*";
        }
        cout << endl;
        counter += 2;
    }
    for(int x = 1; x <= longestRow; x++){
        cout << "*";
    }
    cout << endl;
    counter -= 2;
    for(int k = arrowHead / 2; k >=1 ; k--){
        for(int i = 1; i <= space; i++){
        cout << " ";
        }
        for(int j = 1; j <= counter; j++){
            cout << "*";
        }
        cout << endl;
        counter -= 2;
    }
}

bool isPrime(int val){
    if(val ==1){
        return false;
    }
    if(val == 2){
        return true;
    }
    for(int i = 2; i < val; i++){
        if(val % i == 0){
            return false;
        }
    }
    return true;
}

void printPrimes(int start, int end){
    if(start > end){
        int i;
        i = start;
        start = end;
        end = i;
    }
    int flag = 0;
    for(int j = start; j <= end; j++){
        if(isPrime(j)){
            if(flag == 1){
                cout << ", ";
            }
            cout << j;
            flag = 1;
        }
    }
}

void printMersennePrimes(int start, int end){
    if(start > end){
        int i;
        i = start;
        start = end;
        end = i;
    }
    for(int j = start; j <= end; j++){
        if(isPrime(j)){
            for(int k = 2; k <= j; k++){
                if(isPrime(k) && (pow(2,k) - 1 == j)){
                    cout << j;
                    cout << endl;
                }
            }
        }
    }
}

int sumProperDivisors(int n){
    int total = 0;
    for(int i = 1; i < n; i++){
        if(n % i == 0){
            total += i;
        }
    }
    return total;
}

bool isPerfect(int n){
    int total = 0;
    for(int i = 1; i < n; i++){
        if(n % i == 0){
            total += i;
        }
    }
    if(total == n){
        return true;
    }
    else{
        return false;
    }
}

bool isAbundant(int n){
    int total = 0;
    for(int i = 1; i < n; i++){
        if(n % i == 0){
            total += i;
        }
    }
    if(total > n){
        return true;
    }
    else{
        return false;
    }
}

bool isAmicable(int first, int second){
    int total_1 = 0;
    int total_2 = 0;
    for(int i = 1; i < first; i++){
        if(first % i == 0){
            total_1 += i;
        }
    }
    for(int i = 1; i < second; i++){
        if(first % i == 0){
            total_2 += i;
        }
    }
    if(first == total_2 && second == total_1){
        return true;
    }
    return false;
}
