
void foo(void);

int main () {
    foo();
}
