#include <iostream>
#include <string>
using namespace std;

struct List_Node {
    int value;
    List_Node* next;
};

int main () {

    // add first node
    List_Node first_node;
    first_node.value = 5;
    first_node.next = NULL;

    // add second node
    List_Node second_node;
    second_node.value = 2;
    second_node.next = NULL;
    first_node.next = &second_node;

    // add third node
    List_Node third_node;
    third_node.value = 3;
    third_node.next = NULL;
    second_node.next = &third_node;

    
    // iterate the list
    List_Node * node_ptr = &first_node;
    while (node_ptr != NULL) {
        cout << "Value of this node: " << node_ptr->value << endl;
    
        cout << "Going to next node..." << endl;
        node_ptr = node_ptr->next;
    }
}
