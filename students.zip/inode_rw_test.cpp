//#include "fs_access.h"
#include "fs_server.h"
#include <iostream>
#include <cstring>

using namespace std;

int main() {


    const char* write_data = "This is the data I am writing!";
    disk_writeblock(0,(const void*)write_data);
    char read_data[FS_BLOCKSIZE];
    disk_readblock(0,(void*)read_data);
    cout << read_data << endl;



    fs_inode* file_inode = new fs_inode;
    file_inode->type = 'f';

    const char* owner = "ddrocco";
    strcpy(file_inode->owner,owner);

    file_inode->size = FS_DISKSIZE;
    file_inode->blocks[0] = 2;

    fs_direntry* file_entry = new fs_direntry;
    file_entry->inode_block = 1;

    const char* name = "myfile";
    strcpy(file_entry->name,name);
    return 1;
}
