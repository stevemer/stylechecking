#include "catalog.h"
#include "query.h"
#include "sort.h"
#include "index.h"
#include <cstring>

Status Operators::SNL(const string& result,           // Output relation name
                      const int projCnt,              // Number of attributes in the projection
                      const AttrDesc attrDescArray[], // Projection list (as AttrDesc)
                      const AttrDesc& attrDesc1,      // The left attribute in the join predicate
                      const Operator op,              // Predicate operator
                      const AttrDesc& attrDesc2,      // The left attribute in the join predicate
                      const int reclen)               // The length of a tuple in the result relation
{

	// STILL HAVE DUPLICATE VALUES
	// DO WE NEED TO PROJECT?
	// NEED TO INSERT!	

	cout << "Algorithm: Simple NL Join" << endl;
				
	Status currentStatus = OK;

	HeapFile resultHeapFile = HeapFile(result, currentStatus);
        if (currentStatus != OK) return currentStatus;

 	HeapFileScan leftHeapScan = HeapFileScan(attrDesc1.relName, currentStatus);
	if (currentStatus != OK) return currentStatus;

        //outer record loop
	RID leftRID;
        Record leftRecord;
        while ((currentStatus = leftHeapScan.scanNext(leftRID, leftRecord)) == OK) {
		
		//inner record loop
		HeapFileScan rightHeapScan = HeapFileScan(attrDesc2.relName, currentStatus);
		if (currentStatus != OK) return currentStatus;

		RID rightRID;
		Record rightRecord;
		
		while((currentStatus = rightHeapScan.scanNext(rightRID, rightRecord)) == OK) {
			
			int result = matchRec(leftRecord, rightRecord, attrDesc1, attrDesc2);
			bool insertion = false;

			//Operators::matchRec(blah);
			if (op == LT && result < 0) {
				insertion = true;
			}
			else if (op == LTE && (result < 0 || result == 0)) {
				insertion = true;
			}
			else if (op == GTE && (result > 0 || result == 0)) {
				insertion = true;
			}
			else if (op == GT && result > 0) {
				insertion = true;
			}
			else if (op == NE && result != 0) {
				insertion = true;
			}
			else if (op == NOTSET) {
				insertion = true;
			}

			if (insertion) {
				Record resultRecord;
				resultRecord.data = operator new (reclen);
				resultRecord.length = 0;
				for (int i = 0; i < projCnt; i++) {
					if (attrDescArray[i].relName == attrDesc1.relName) {
						memcpy((char*)resultRecord.data + resultRecord.length,
							(char*)leftRecord.data + attrDescArray[i].attrOffset,
							attrDescArray[i].attrLen);
					}
					else {
						memcpy((char*)resultRecord.data + resultRecord.length,
							(char*)rightRecord.data + attrDescArray[i].attrOffset,
							attrDescArray[i].attrLen);
					}

					resultRecord.length += attrDescArray[i].attrLen;
				}
				
				RID outRID;
				resultHeapFile.insertRecord(resultRecord, outRID);
			}
		}
		// check errors here
	}
	// check errors here

        if (currentStatus != OK) return currentStatus;
	else return OK;
	/* Your solution goes here */

}

