#include <iostream>
using namespace std;

void memberFunction(int& n){
    n = 0;
}

class Class{
private:
    int n;
public:
    void publicFunction();
};

void Class::publicFunction(){
    memberFunction(n);
}

int main () {
    Class me;
    me.publicFunction();
}
