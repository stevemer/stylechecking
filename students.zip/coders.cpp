#include <iostream>
#include <cmath>
using namespace std;

int main () {

double a = 1.5;
int b = static_cast<int>(ceil(a));
cout << b << endl; // will print 2

}
