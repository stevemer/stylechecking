#include <iostream>
#include <cstdlib>
#include <string>
#include <algorithm>
#include <vector>
#include <climits>
using namespace std;

typedef std::vector<int> V;
typedef std::vector<int>::iterator V_iter;

void fnn(V vectorname, int index) {
	std::cout << vectorname[index];
}

void funn2(V vectorname) {
	for (int i = 0; i < vectorname.size(); i++) {
		fnn(vectorname, i);
	}
}

void fna(V::iterator begin, V::iterator end) {
	int vectorsize = end - begin;
	if (vectorsize < 2) return;
	vectorsize /= 2;
	fna(begin, begin + vectorsize);
	fna(begin + vectorsize, end);
	for (auto x = begin; begin < end; begin++) {
		std::cout << *x << " ";
	}
	std::cout << endl;

	for (int i = 0; i < 5; i++) {
		std::cout << "-";
	}
	std::cout << endl;		
}

void fnb(V vectorname) {
	for (int i = 0; i < INT_MAX; i++) {
		funn2(vectorname);
	}
	fna(vectorname.begin(), vectorname.end());
}

int main () {
	std::vector<int> myvector(20);
	for (int i = 0; i < myvector.size(); i++) {
		myvector[i] = i+1;
	}
	fnb(myvector);	
}
