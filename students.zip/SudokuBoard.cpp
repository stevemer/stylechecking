// Author:
// Uniqname:
// Date:
// GSI:
// Description

#include "ioutil.h"
#include "SudokuBoard.h"
#include "sudoku.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void SudokuBoard::printBoard()
{
   // print the numbers at the top of the board
   cout << ' ';
   for(int y = 0; y < BOARD_SIZE; y ++)
   {
       if (y < 9)
           cout << "| " << SetColor(INDEX_COLOR) << y + 1 << ' ';
       else
           cout << "| " << SetColor(INDEX_COLOR) << y + 1 ;
   }
   cout << '|' << endl;
   
   for(int x = 0; x < BOARD_SIZE; x ++)
   {
       cout << '-';
       
       // print a line above the cell
       for(int y = 0; y < BOARD_SIZE; y ++)
       {
           if(x % BOARD_N == 0)
           {
               cout << SetColor(WHITE, BACK) << "+---";
           }
           else
           {
               if(y % BOARD_N == 0)
               {
                   cout << SetColor(WHITE, BACK) << '+';
               }
               else
               {
                   cout << '+';
               }
               
               cout << "---";
           }
       }
       
       cout << SetColor(WHITE, BACK) << '+' << '-' << endl;
       cout << SetColor(INDEX_COLOR) << char(x + 'A');
       
       // print the contents of the cell
       for(int y = 0; y < BOARD_SIZE; y ++)
       {
           if(y % BOARD_N == 0)
           {
               cout << SetColor(WHITE, BACK) << '|';
           }
           else
           {
               cout << '|';
           }
           if(board[x][y].permanent)
           {
               cout << ' ' << SetColor(PERMANENT_NUMBER_COLOR) << board[x][y].number;
           }
           else
           {
               cout << ' ';
               if (board[x][y].number == 0) {
                   cout << ' ';
               } else {
                   cout << board[x][y].number;
               }
           }
           if (board[x][y].number < 10) {
               cout << ' ';
           }
       }
       cout << SetColor(WHITE, BACK) << '|' << SetColor(INDEX_COLOR) << char(x + 'A') << endl;
   }
   
   cout << '-';
   
   // print the final line
   for(int y = 0; y < BOARD_SIZE; y ++)
   {
       cout << SetColor(WHITE, BACK) << "+---";
   }
   cout << SetColor(WHITE, BACK) << '+' << '-' << endl;
   
   // print the numbers at the bottom of the board
   cout << ' ';
   for(int y = 0; y < BOARD_SIZE; y ++)
   {
       if (y < 9)
           cout << "| " << SetColor(INDEX_COLOR) << y + 1 << ' ';
       else
           cout << "| " << SetColor(INDEX_COLOR) << y + 1 ;
   }
   cout << '|' << endl << endl;
}

SudokuBoard::SudokuBoard() {
   initBoard();
}

void SudokuBoard::initBoard() {
   for (int i = 0; i < BOARD_SIZE; i++) {//rows
       for (int j = 0; j < BOARD_SIZE; j++) {//cols
           board[i][j].number = 0;
           board[i][j].permanent = false;
       }
   }
   emptySqrCount = BOARD_SIZE * BOARD_SIZE;
}

bool SudokuBoard::loadBoard() {
   ifstream ins;
   string row;
   if (openFile(ins)) {
       for (int i = 0; i < BOARD_SIZE; i++) {
           getline(ins, row);
           for (int j = 0; j < BOARD_SIZE; j++) {
               if (row[j] >= '1' && row[j] <= '9') {
                   board[i][j].number = row[j] - '0';
                   board[i][j].permanent = true;
                   emptySqrCount--;
               }
               if ((row[j] != ' ') && !(row[j] >= '1' && row[j] <= '9')) {
                   initBoard();
                   ins.clear();
                   cout << "File didn't read properly";
                   return false;
               }
           }
       }
       cout << "Board loaded successfully";
       return true;
   }
   else {
       cout << "File didn't read properly";
       return false;
   }
}

bool SudokuBoard::isValidMove(int row, int col, int value) const {
   int counter = 0;
   for (int i = 0; i < BOARD_SIZE; i++) {
       if (board[row][i].number == value && i != col) {
           cout << "That value is in conflict in this row";
           counter++;
       }
   }
   for (int j = 0; j < BOARD_SIZE; j++) {
       if (board[j][col].number == value && j != row) {
           cout << "That value is in conflict in this column";
           counter++;
       }
   }
   const int gridNum = 3;
   int gridRow = (row / gridNum) * gridNum;
   int gridCol = (col / gridNum) * gridNum;
   int rowLim = gridRow + 2;
   int colLim = gridCol + 2;
   for (int x = gridRow; x <= rowLim; x++) {
       for (int y = gridCol; y <= colLim; y++) {
           if (board[x][y].number == value && (x != row || y != col)) {
               cout << "That value is in conflict in this subgrid";
               counter++;
           }
       }
   }
   if (counter > 0) {
       return false;
   }
   else {
       return true;
   }
}

void SudokuBoard::placeValue() {
   int row = 0;
   int col = 0;
   if (getCoords(row, col)) {
       if (board[row][col].permanent) {
           cout << "That location cannot be changed";
       }
       else {
           int value;
           cin >> value;
           if (cin.fail()) {
               cout << "Invalid number";
               clearInput(cin);
           }
           else if (value < 1 || value > BOARD_SIZE) {
               cout << "Invalid number";
           }
           else if (isValidMove(row, col, value)) {
               if (board[row][col].number == 0) {
                   emptySqrCount--;
               }
               board[row][col].number = value;
           }
       }
   }
}

void SudokuBoard::deleteValue() {
   int row = 0;
   int col = 0;
   if (getCoords(row, col)) {
       if (board[row][col].permanent) {
           cout << "That location cannot be changed";
       }
       else {
           board[row][col].number = 0;
           emptySqrCount++;
       }
   }
}

bool SudokuBoard::isFull() const {
   for (int i = 0; i < BOARD_SIZE; i++) {
       for (int j = 0; j < BOARD_SIZE; j++) {
           if (board[i][j].number == 0) {
               return false;
           }
       }
   }
   return true;
}

unsigned int SudokuBoard::getNumEmptySquares() const {
   int counter = 0;
   for (int i = 0; i < BOARD_SIZE; i++) {
       for (int j = 0; j < BOARD_SIZE; j++) {
           if (board[i][j].number == 0) {
               counter++;
           }
       }
   }
   return counter;
}

void SudokuBoard::playGame() {
   while (!isFull()) {
       printBoard();
       cout << "Enter a move: ";
       char command;
       cin >> command;
       if (command == 'p' || command == 'P')
           placeValue();
       else if (command == 'd' || command == 'D')
           deleteValue();
       else if (command == 'q' || command == 'Q')
           return;
       else {
           printCommands();
           clearInput(cin);
       }
   }
   cout << "You did it - congrats!";
   printBoard();
}
